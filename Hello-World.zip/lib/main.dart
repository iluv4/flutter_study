import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// 오류 1: 클래스 이름이 일치하지 않음 (MyApp vs Myapp)
// Error 1: Inconsistent class name (MyApp vs Myapp)
class Myapp extends StatelessWidget {
  // 오류 2: 백슬래시(\)가 불필요하게 들어감
  // Error 2: Unnecessary backslash(\)
  const Myapp ({ Key? key }) : super(key: key);\

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // 오류 3: home 속성이 중복됨 (하나만 사용해야 함)
      // Error 3: Duplicate 'home' property (should only use one)
      home: Icon(Icon.star),  // 오류 4: Icon.star가 아닌 Icons.star를 사용해야 함
                             // Error 4: Should use Icons.star instead of Icon.star
      home: Text('hi'),
      
    );
  }
}